package com.hcl.commerce.search.internal.expression.postprocessor;

/*
 * Licensed Materials - Property of HCL Technologies Limited. (C) Copyright HCL Technologies Limited 1996, 2020.
 */

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.slf4j.Logger;
import org.elasticsearch.search.aggregations.Aggregation;
import org.elasticsearch.search.aggregations.Aggregations;
import org.elasticsearch.search.aggregations.bucket.filter.ParsedFilter;
import org.elasticsearch.search.aggregations.bucket.terms.ParsedDoubleTerms;

import com.hcl.commerce.search.expression.SearchCriteria;
import com.hcl.commerce.search.expression.SearchExpressionConstants;
import com.hcl.commerce.search.expression.SearchResponse;
import com.hcl.commerce.search.internal.config.ValueMappingService;
import com.hcl.commerce.search.internal.expression.processor.SearchQueryPostprocessor;
import com.hcl.commerce.search.internal.runtime.SearchServiceFacade;
import com.hcl.commerce.search.internal.util.FacetHelper;
import com.hcl.commerce.search.rest.util.SpecialCharacterHelper;

public class SearchFacetQueryPostprocessor extends AbstractSearchQueryPostprocessor
		implements SearchQueryPostprocessor {

	private static final String CLASSNAME = SearchFacetQueryPostprocessor.class.getName();
	private static final Logger LOGGER = LoggerFactory.getLogger(CLASSNAME);

	private final static String ENTRY = "Entry";
	private final static String NAME = "name";
	private final static String VALUE = "value";

	private final static String COUNT = "count";
	private final static String LABEL = "label";
	private final static String UNIQUE_ID = "uniqueId";
//	private static final String PARENT_IDS = "parentIds";
	private static final String EXTENDED_DATA = "extendedData";
	private LinkedList<Map<String, Object>> iFacetValues = new LinkedList<Map<String, Object>>();
	private String iFacetEntry = null;
	private String iFacetName = null;
	private String iFacetValue = null;

	@Override
	public void invoke(SearchCriteria searchCriteria, Object... queryResponseObjects) throws Exception {

		if (LOGGER.isTraceEnabled()) {
			LOGGER.trace("ENTRY");
			LOGGER.trace("Search Criteria : " + searchCriteria);
			LOGGER.trace("HitResults : " + ((SearchResponse)queryResponseObjects[0]).getMatches());
		}
		
		super.invoke(searchCriteria, queryResponseObjects);
		
		ValueMappingService mappingService = ValueMappingService.getInstance();

//		String strSearchProfile = iSearchCriteria.getControlParameterValue(SearchExpressionConstants.CTRL_PARAM_SEARCH_PROFILE);
//		String strCurrencyCode = iSearchCriteria.getControlParameterValue(SearchExpressionConstants.CTRL_PARAM_SEARCH_CURRENCY);
		String strCatalogId = iSearchCriteria.getControlParameterValue(SearchExpressionConstants.CTRL_PARAM_SEARCH_CATALOG);
//		String strCategoryId = iSearchCriteria.getControlParameterValue(SearchExpressionConstants.CTRL_PARAM_SEARCH_CATEGORY);
		String strLanguageId = iSearchCriteria.getControlParameterValue(SearchExpressionConstants.CTRL_PARAM_SEARCH_LANGUAGE);
		String strStoreId = iSearchCriteria.getControlParameterValue(SearchExpressionConstants.CTRL_PARAM_SEARCH_STORE_ONLINE);

		String responseTemplate = iSearchCriteria
				.getControlParameterValue(SearchExpressionConstants.CTRL_PARAM_SEARCH_INTERNAL_RESPONSE_TEMPLATE);

		org.elasticsearch.action.search.SearchResponse queryResponse = iSearchResponseObject.getQueryResponse();

		if (responseTemplate == null || responseTemplate.length() == 0) {
			// Look up wc-component.xml for site default configuration
			responseTemplate = mappingService.getExtendedConfigurationPropertyValue(
					SearchExpressionConstants.PROPERTY_NAME_RESPONSE_TEMPLATE_DEFAULT);
		}

		// Defaults to noun based template
		if (responseTemplate == null || responseTemplate.length() == 0) {
			// Defaults to BOD-like structure template if still not defined
			responseTemplate = SearchExpressionConstants.RESPONSE_TEMPLATE_NOUN;
		}
		if (LOGGER.isTraceEnabled()) {
			LOGGER.trace("Response template: " + responseTemplate);
		}
		if (responseTemplate.equals(SearchExpressionConstants.RESPONSE_TEMPLATE_RAW)) {
			LOGGER.trace("EXIT");
			return;
		}

		String resourceName = iSearchCriteria
				.getControlParameterValue(SearchExpressionConstants.CTRL_PARAM_SEARCH_INTERNAL_SERVICE_RESOURCE);
		String mapperReferenceName = new StringBuffer(SearchExpressionConstants.RESPONSE_TEMPLATE_NAME_PREFIX)
				.append(SearchExpressionConstants.RESPONSE_TEMPLATE_VALUE_SEPARATOR).append(responseTemplate)
				.append(SearchExpressionConstants.RESPONSE_TEMPLATE_VALUE_SEPARATOR).append(resourceName)
				.append(SearchExpressionConstants.RESPONSE_TEMPLATE_VALUE_SEPARATOR)
				.append(SearchExpressionConstants.FACET_VIEW).toString();
		String mapperName = mappingService.getExtendedConfigurationPropertyValue(mapperReferenceName);

		final String M_FACET_VIEW = String
				.valueOf(mappingService.getExternalKey(mapperName, SearchExpressionConstants.FACET_VIEW));
		final String M_FACET_VIEW_SLASH = M_FACET_VIEW + SearchExpressionConstants.RESPONSE_TEMPLATE_VALUE_SEPARATOR;

		int lenPrefix = M_FACET_VIEW_SLASH.length();
		String strFacetEntry = String.valueOf(mappingService.getExternalKey(mapperName, ENTRY));
		if (strFacetEntry.startsWith(M_FACET_VIEW_SLASH)) {
			strFacetEntry = strFacetEntry.substring(lenPrefix);
		}
		String strFacetValue = String.valueOf(mappingService.getExternalKey(mapperName, VALUE));
		if (strFacetValue.startsWith(M_FACET_VIEW_SLASH)) {
			strFacetValue = strFacetValue.substring(lenPrefix);
		}
		String strFacetName = String.valueOf(mappingService.getExternalKey(mapperName, NAME));
		if (strFacetName.startsWith(M_FACET_VIEW_SLASH)) {
			strFacetName = strFacetName.substring(lenPrefix);
		}
		boolean zeroFacetFlag = false;
		Aggregations aggregation = queryResponse.getAggregations();
		if (aggregation != null) {
			Iterator<Entry<String, Aggregation>> itr = aggregation.asMap().entrySet().iterator();
			//BEGIN : Logic to create facet property map from control parameters
			List<String> facetProperties = searchCriteria.getControlParameterValues(SearchExpressionConstants.CTRL_PARAM_SEARCH_FACET_PROPERTIES);
			
			//Map<String, Map> queryMap = new HashMap<>();
			//check if any facet has been selected in the query for performing 0 facet post query
			if (queryResponse.getHits().getTotalHits().value>0)
			if (null!=searchCriteria.getControlParameterValue(SearchExpressionConstants.CTRL_PARAM_SEARCH_FACET) 
					&& !searchCriteria.getControlParameterValue(SearchExpressionConstants.CTRL_PARAM_SEARCH_FACET).isEmpty()) {
				for (String facetProp:facetProperties) {
					List<String> facetPropList = Arrays.asList(facetProp.split(","));
					if (facetPropList.contains("zero_display=true")) {
						zeroFacetFlag = true;
						break;
					}
				}
		}
//			String name = null;
			Map<String, Map<String, String>> queryMap = new HashMap<>();
			if (facetProperties != null && facetProperties.size() > 0) {
			for (String entry : facetProperties) {
				Map <String, String> facetMap = new HashMap<>();
				List<String> keyList = new ArrayList<String>();
				List<String> valueList = new ArrayList<String>();
				
				//Splitting it this way to prevent issues if the facet value contains commas
				String[] splitByEqual = entry.split("=");
				for(int i=0; i<splitByEqual.length; i++) {
					if(i==0) {
						keyList.add(splitByEqual[i]);
					}
					else if(i==splitByEqual.length-1) {
						String val = splitByEqual[i];
						if(val.endsWith(","));
							val = val.substring(0, val.length()-1);
						valueList.add(val);
					}
					else {
						int lastCommaIndex = splitByEqual[i].lastIndexOf(",");
						valueList.add(splitByEqual[i].substring(0, lastCommaIndex));
						keyList.add(splitByEqual[i].substring(lastCommaIndex+1, splitByEqual[i].length()));
					}
				}
				
				for(int i=0; i<keyList.size(); i++) {
					facetMap.put(keyList.get(i), valueList.get(i));
				}

				if (facetMap.get("propertyvalue")!=null) {
					if (facetMap.get("propertyvalue").toString().equals("manufacturer.raw")) {
						queryMap.put("manufacturer.raw", facetMap);
					}else if (facetMap.get("propertyvalue").toString().equals("seller.raw")) {
						queryMap.put("seller.raw", facetMap);
					}else if (facetMap.get("propertyvalue").toString().equals("path")) {
						queryMap.put("path", facetMap);
					}
					/* BV START */
					else if(facetMap.get("propertyvalue").toString().equals("BVcustom.X_FIELD3")) {
						queryMap.put("BVcustom.X_FIELD3", facetMap);
					}
					/* BV END */
					else {
						queryMap.put("facets" + "." + facetMap.get("propertyId") + "." + "value.raw", facetMap);
					}
				}
				
			}
				
			}
			//END : Logic to create facet property map from control parameters
			Map<String, List<String>> zeroFacetMap = new HashMap<>();
			if (zeroFacetFlag) {
				zeroFacetMap = createZeroFacetQuery(searchCriteria);
			}
			LinkedList<Map<String, Object>> facetValues = new LinkedList<Map<String, Object>>();
			if (queryResponse.getHits().getTotalHits().value>0)
			while (itr.hasNext()) {
				Entry<String, Aggregation> entry = itr.next();
				if (entry.getKey().toString().startsWith("prices.")) {
					mediateFacetForPrice(
						aggregation.asMap(),
						entry.getKey(),
						facetValues,
						strFacetValue,
						strFacetName,
						strFacetEntry);
				} 
				/* BV START */
				else if(entry.getKey().toString().startsWith("BVcustom.")) {
					mediateFacetForRating(aggregation.asMap(), entry.getKey(), facetValues,
							strFacetValue,
							strFacetName,
							strFacetEntry);
				/* BV END */
				} else {
					mediateFacet(
						aggregation.asMap(),
						entry.getKey(),
						searchCriteria,
						queryMap,
						zeroFacetMap,
						zeroFacetFlag,
						strStoreId,
						strLanguageId,
						facetValues,
						strFacetValue,
						strFacetName,
						strFacetEntry,
						strCatalogId);
				}
			}
			facetValues = sortFacetList(facetValues);
			iSearchResponseObject.getResponse().put(M_FACET_VIEW, facetValues);
		}

		LOGGER.trace("EXIT");
	}
	private LinkedList<Map<String, Object>> sortFacetList(LinkedList<Map<String, Object>> aFacetValues) {
		LinkedList<Map<String, Object>> sortedFacetList = new LinkedList<>();
		Map<String, Map<String, Object>> nameValueMap = new HashMap<>();
		if (!aFacetValues.isEmpty()) {
			Map<String, Float> sortValueMap = new HashMap<>();
			for (Map<String, Object> facetMap : aFacetValues) {
				if (facetMap.get("extendedData")!=null && ((Map) facetMap.get("extendedData")).get("displaySequence")!=null){
					sortValueMap.put(facetMap.get("value").toString(), Float.valueOf(((Map)facetMap.get("extendedData")).get("displaySequence").toString()));
					nameValueMap.put(facetMap.get("value").toString(),facetMap);
					
				}else {
					sortValueMap.put(facetMap.get("value").toString(), new Float("0.0"));
					nameValueMap.put(facetMap.get("value").toString(), facetMap);
				}
				
			}
			 List<Map.Entry<String, Float> > list = new LinkedList<Map.Entry<String, Float>>(sortValueMap.entrySet()); 
		  
		        // Sort the list 
		        Collections.sort(list, new Comparator<Map.Entry<String, Float> >() { 
		            public int compare(Map.Entry<String, Float> o1,  
		                               Map.Entry<String, Float> o2) 
		            { 
		                return (o1.getValue()).compareTo(o2.getValue()); 
		            } 
		        }); 
		          
		        // put data from sorted list to hashmap  
		        HashMap<String, Float> temp = new LinkedHashMap<String, Float>(); 
		        for (Map.Entry<String, Float> aa : list) { 
		            temp.put(aa.getKey(), aa.getValue()); 
		        }
		        for (String tempName :temp.keySet()) {
		        	sortedFacetList.add(nameValueMap.get(tempName));
		        }
		}
		return sortedFacetList;
	}
	private void mediateFacetForPrice(
		Map aggregationMap,
		final String key,
		LinkedList<Map<String, Object>> aFacetValues,
		String astrFacetValue,
		String astrFacetName,
		String astrFacetEntry) throws UnsupportedEncodingException {

		if (LOGGER.isTraceEnabled()) {
			LOGGER.trace("ENTRY");
			LOGGER.trace("Aggregation Map keys: " + aggregationMap.keySet());
			LOGGER.trace("Key : " + key);
		}

		
		Map<Double, Long> prices = new HashMap<>();
		Object obj = aggregationMap.get(key);
		
		if (obj instanceof ParsedDoubleTerms || obj instanceof ParsedFilter) {
			List buckets = new ArrayList<>();
			double maxPrice = 0.0;
			Double bucketSizeDbl = 0.0;
			int bucketSize = 0;
			
			if (obj instanceof ParsedDoubleTerms) {
				buckets = ((ParsedDoubleTerms) obj).getBuckets();
			}else if (obj instanceof ParsedFilter) {
				if ((((ParsedFilter) obj).getAggregations().asList().get(0)) instanceof ParsedDoubleTerms) {
					buckets = ((ParsedDoubleTerms) ((ParsedFilter) obj).getAggregations().asList().get(0)).getBuckets();
				}
			}
			if (buckets!=null && !buckets.isEmpty()) {
			Iterator it = buckets.iterator();
			while (it.hasNext()) {
				ParsedDoubleTerms.ParsedBucket item = (ParsedDoubleTerms.ParsedBucket) it.next();
				if ((double)item.getKey()>maxPrice) {
					maxPrice = (Double)item.getKey();
				}
				prices.put((Double)item.getKey(),item.getDocCount());
			}
			if (maxPrice > 0)
				bucketSize = (int) (maxPrice/5);
			if (bucketSize == 0)
				bucketSize=1;
			bucketSizeDbl = (double) bucketSize;
			List<Integer> bucketCount = Arrays.asList(0,0,0,0,0,0);
		
		 for (double price : prices.keySet()) {
			 if (price<= bucketSizeDbl) {
				 bucketCount.set(0, bucketCount.get(0)+prices.get(price).intValue());
			 }else if(isBetween(price, bucketSizeDbl, bucketSizeDbl*2)) {
				 bucketCount.set(1, bucketCount.get(1)+prices.get(price).intValue());				 
			 }else if(isBetween(price, bucketSizeDbl*2, bucketSizeDbl*3)) {
				 bucketCount.set(2, bucketCount.get(2)+prices.get(price).intValue());				 
			 }else if(isBetween(price, bucketSizeDbl*3, bucketSizeDbl*4)) {
				 bucketCount.set(3, bucketCount.get(3)+prices.get(price).intValue());				 
			 }else if(isBetween(price, bucketSizeDbl*4, bucketSizeDbl*5)) {
				 bucketCount.set(4, bucketCount.get(4)+prices.get(price).intValue());				 
			 }else if(isBetween(price, bucketSizeDbl*5, bucketSizeDbl*6)) {
				 bucketCount.set(5, bucketCount.get(5)+prices.get(price).intValue());
			 }
		 }
		 addFacetEntry(bucketCount, bucketSizeDbl,key, aFacetValues, astrFacetValue, astrFacetName, astrFacetEntry);
		}
		}
		LOGGER.trace("EXIT");
	}
	private boolean isBetween(double val, double min, double max) {
		return (val > min && val <= max);
	}

	private void addFacetEntry(
		List<Integer> bucketCount,
		final Double bucketSizeDbl,
		String key,
		LinkedList<Map<String, Object>> aFacetValues,
		String astrFacetValue,
		String astrFacetName,
		String astrFacetEntry) throws UnsupportedEncodingException {

		if (LOGGER.isTraceEnabled()) {
			LOGGER.trace("Facet Info : " + bucketCount);
			LOGGER.trace("Facet Name : " + bucketSizeDbl);
		}
		List<Map<String, Object>> lFacetEntryValues = new LinkedList<Map<String, Object>>();
		Map<String, Object> facetValue = new LinkedHashMap<String, Object>();
		Map<String, Object> facetEntry = null;
		aFacetValues.add(facetValue);
		String label = "";
		String[] keySplit = key.split("\\.");
		for (int i= 1 ; i <= bucketCount.size();i++) {
				
				facetEntry = new HashMap<String, Object>();
			if (i == 1) {
				label = "({* TO "+bucketSizeDbl.intValue()+"])";
				facetEntry.put(COUNT, bucketCount.get(0));
				facetEntry.put(LABEL, label);//({* TO 100])
			}
			else if(i == bucketCount.size()) {
				label = "({"+bucketSizeDbl.intValue()*(i-1)+" TO * ])";
				facetEntry.put(COUNT, bucketCount.get(i-1));
				facetEntry.put(LABEL, label);//({500 TO *])
			}else {
				label = "({"+bucketSizeDbl.intValue()*(i-1)+" TO "+bucketSizeDbl.intValue()*i+"])";
				facetEntry.put(COUNT, bucketCount.get(i-1));
				facetEntry.put(LABEL, label);
			}
			Map<String, Object> extendedData = new HashMap<String, Object>();
			facetEntry.put(EXTENDED_DATA, extendedData);
			String strExpression = "price_"+keySplit[keySplit.length - 1] + SearchExpressionConstants.EXPRESSION_OPERATOR_ASSIGN + label;
			String uniqueId = SpecialCharacterHelper.convertStrToAscii(strExpression);
			extendedData.put(UNIQUE_ID, uniqueId);
			facetEntry.put(astrFacetValue, URLEncoder.encode(strExpression, SearchExpressionConstants.ENCODING_UTF_8));
			lFacetEntryValues.add(facetEntry);
		}
		facetValue.put(astrFacetEntry, lFacetEntryValues);
		facetValue.put(astrFacetValue, "price_"+keySplit[keySplit.length - 1]);
		facetValue.put(astrFacetName, "OfferPrice_"+keySplit[keySplit.length - 1]);
		
		
		if (LOGGER.isTraceEnabled()) {
			LOGGER.trace("FacetEntry : " + facetEntry);
		}
		
	}
	/* BV START */
	/**
	 * Custom logic to add Facet for Rating
	 * @param aggregationMap
	 * @param key
	 * @throws UnsupportedEncodingException
	 */
	private void mediateFacetForRating(Map aggregationMap, final String key, LinkedList<Map<String, Object>> aFacetValues,
			String astrFacetValue,
			String astrFacetName,
			String astrFacetEntry) throws UnsupportedEncodingException {
		if (LOGGER.isTraceEnabled()) {
			LOGGER.trace("ENTRY");
			LOGGER.trace("Aggregation Map keys: " + aggregationMap.keySet());
			LOGGER.trace("Key : " + key);
		}

		Map<Double, Long> ratings = new HashMap<>();
		Object obj = aggregationMap.get(key);

		if (obj instanceof ParsedDoubleTerms || obj instanceof ParsedFilter) {
			List buckets = new ArrayList<>();
			Double maxRating = 5.0;

			if (obj instanceof ParsedDoubleTerms) {
				buckets = ((ParsedDoubleTerms) obj).getBuckets();
			} else if (obj instanceof ParsedFilter) {
				if ((((ParsedFilter) obj).getAggregations().asList().get(0)) instanceof ParsedDoubleTerms) {
					buckets = ((ParsedDoubleTerms) ((ParsedFilter) obj).getAggregations().asList().get(0)).getBuckets();
				}
			}
			if (buckets != null && !buckets.isEmpty()) {
				Iterator it = buckets.iterator();
				while (it.hasNext()) {
					ParsedDoubleTerms.ParsedBucket item = (ParsedDoubleTerms.ParsedBucket) it.next();
					ratings.put((Double)item.getKey(),item.getDocCount());
				}
				List<Integer> bucketCount = Arrays.asList(0, 0, 0, 0, 0);

				for (double rating : ratings.keySet()) {
					if (rating >= maxRating) {
						bucketCount.set(0, bucketCount.get(0) + ratings.get(rating).intValue());
					} else if (isBetweenForRating(rating, maxRating - 1, maxRating)) {
						bucketCount.set(1, bucketCount.get(1) + ratings.get(rating).intValue());
					} else if (isBetweenForRating(rating, maxRating - 2, maxRating - 1)) {
						bucketCount.set(2, bucketCount.get(2) + ratings.get(rating).intValue());
					} else if (isBetweenForRating(rating, maxRating - 3, maxRating - 2)) {
						bucketCount.set(3, bucketCount.get(3) + ratings.get(rating).intValue());
					} else if (isBetweenForRating(rating, maxRating - 4, maxRating - 3)) {
						bucketCount.set(4, bucketCount.get(4) + ratings.get(rating).intValue());
					}
				}
				addFacetEntryForRating(bucketCount, maxRating, key, aFacetValues, astrFacetValue, astrFacetName, astrFacetEntry);
			}
		}
		LOGGER.trace("EXIT");
	}
	
	/**
	 * 
	 * @param val
	 * @param min
	 * @param max
	 * @return
	 */
	private boolean isBetweenForRating(double val, double min, double max) {
		return (val >= min && val < max);
	}
	
	/**
	 * Custom logic to add Facet Entry for Ratings
	 * @param bucketCount
	 * @param bucketSizeDbl
	 * @param key
	 * @throws UnsupportedEncodingException
	 */
	private void addFacetEntryForRating(List<Integer> bucketCount, final Double bucketSizeDbl, String key, LinkedList<Map<String, Object>> aFacetValues,
			String astrFacetValue,
			String astrFacetName,
			String astrFacetEntry) throws UnsupportedEncodingException {

		if (LOGGER.isTraceEnabled()) {
			LOGGER.trace("Facet Info : " + bucketCount);
			LOGGER.trace("Facet Name : " + bucketSizeDbl);
		}
		List<Map<String, Object>> lFacetEntryValues = new LinkedList<Map<String, Object>>();
		Map<String, Object> facetValue = new LinkedHashMap<String, Object>();
		Map<String, Object> facetEntry = null;
		aFacetValues.add(facetValue);
		String label = "";
		
		for (int i= 0 ; i < bucketCount.size();i++) {
			
			facetEntry = new HashMap<String, Object>();
			label = "([" + (bucketSizeDbl.intValue() - i) + " TO " + (bucketSizeDbl.intValue() + 1 - i) + "})";
			facetEntry.put(COUNT, bucketCount.get(i));
			facetEntry.put(LABEL, label);
			
			Map<String, Object> extendedData = new HashMap<String, Object>();
			facetEntry.put(EXTENDED_DATA, extendedData);
			String strExpression = key + SearchExpressionConstants.EXPRESSION_OPERATOR_ASSIGN + label;
			String uniqueId = SpecialCharacterHelper.convertStrToAscii(strExpression);
			extendedData.put(UNIQUE_ID, uniqueId);
			facetEntry.put(astrFacetValue, URLEncoder.encode(strExpression, SearchExpressionConstants.ENCODING_UTF_8));
			lFacetEntryValues.add(facetEntry);
		}
		facetValue.put(astrFacetEntry, lFacetEntryValues);
		facetValue.put(astrFacetValue, key);
		facetValue.put(astrFacetName, "Rating");
		
		
		if (LOGGER.isTraceEnabled()) {
			LOGGER.trace("FacetEntry : " + facetValue.get(astrFacetEntry));
		}
	}
	/* BV END */

	private void mediateFacet(
		Map aggregationMap,
		final String key,
		SearchCriteria searchCriteria,
		Map<String, Map<String, String>> queryMap,
		Map<String, List<String>> zeroFacetMap,
		boolean zeroFacetFlag,
		String astrStoreId,
		String astrLanguageId,
		LinkedList<Map<String, Object>> aFacetValues,
		String astrFacetValue,
		String astrFacetName,
		String astrFacetEntry,
		String astrCatalogId)  throws Exception {

		if (LOGGER.isTraceEnabled()) {
			LOGGER.trace("ENTRY");
			LOGGER.trace("Aggregation Map keys: " + aggregationMap.keySet());
			LOGGER.trace("Key : " + key);
			LOGGER.trace("Search Criteria : " + searchCriteria);
		}

		String facetKey = null;
		boolean bSkipLastValue = false;
		List<String> validValues = new ArrayList<>();

		if (key != null && key.contains(".keyword")) {
			facetKey = key.replace(".keyword", "");
		} else {
			facetKey = key;
		}
		if (null!=zeroFacetMap && !zeroFacetMap.isEmpty()) {
			String removeKey = ""; 
			if (facetKey.equals("path")) {
				removeKey = "parentCatgroup_id_search";
			}else {
				removeKey = facetKey;
			}
			if (null!=zeroFacetMap.get(removeKey)) {
				validValues.addAll(zeroFacetMap.get(removeKey));
			}else {
				if (zeroFacetFlag)
					return;
			}
		}
		Map<String, String> indMap = new HashMap<>();
		String allValuesReturned = "true";
		indMap=(Map<String, String>) queryMap.get(key);
		List<Map<String, Object>> facetEntries = FacetHelper.facetValues(aggregationMap.get(key), facetKey,
				bSkipLastValue, astrCatalogId, astrStoreId, searchCriteria, indMap, astrLanguageId);
		List<Integer> reomveIndices = new ArrayList<>();
		//if there is no facet selected, remove empty entries
		if (null==searchCriteria.getControlParameterValue(SearchExpressionConstants.CTRL_PARAM_SEARCH_FACET) 
				|| searchCriteria.getControlParameterValue(SearchExpressionConstants.CTRL_PARAM_SEARCH_FACET).isEmpty()) {
			//List<Map<String, Object>> removeZero = new ArrayList(facetEntries);

			for (int i =0; i<facetEntries.size(); i++) {
				Map fEntry = facetEntries.get(i);
				if (null!=fEntry.get("count")) {
					if (fEntry.get("count").equals("0")) {
						reomveIndices.add(i);
					}
				}
			}
		}
		Map<String, Object> facetValue = new LinkedHashMap<String, Object>();
		if (facetEntries != null && !facetEntries.isEmpty()) {
			if (null!=validValues && !validValues.isEmpty()) {
				//List<Map<String, Object>> tempFacetEntries = new ArrayList(facetEntries);
				for (int i =0; i<facetEntries.size(); i++) {
					Map fEntry = facetEntries.get(i);
					if (null!=fEntry.get("value")) {
						if (!validValues.contains(fEntry.get("value"))) {
							reomveIndices.add(i);
						}
					}
				}
			}
			if (null!=reomveIndices && !reomveIndices.isEmpty()) {
				List finalValues = new ArrayList();
				for(int x=0; x<facetEntries.size();x++) {
					if (!reomveIndices.contains(x)) {
						finalValues.add(facetEntries.get(x));
					}
				}
				facetEntries = finalValues;
			}
			if (facetKey.equals("path")) {
				facetValue.put(astrFacetValue, "parentCatgroup_id_search");
			}else {
				facetValue.put(astrFacetValue, facetKey);
			}
			if (indMap!= null ) {
				if (indMap.get("unitID")!=null) {
					indMap.remove("unitID");
				}
				if (indMap.get("unitOfMeasure")!=null) {
					indMap.remove("unitOfMeasure");
				}
				if (indMap.get("name")!=null) {
					if (indMap.get("name").equals("Category")) {
						facetValue.put(astrFacetName, "ParentCatalogGroup");
					}else {
						facetValue.put(astrFacetName, indMap.get("name"));
					}
				}else {
					facetValue.put(astrFacetName, indMap.get("propertyvalue"));
				}
				/*This piece will check if facet has maximumVluesToDisplay is less than buckets in the facet and reduce the number of buckets.
				But if facetLimit param is passed along, it will be checked for the applicable Facets. This will help with show all/show less link on storefront*/
				if (indMap!=null && indMap.get("maximumValuesToDisplay")!=null) {
					if (!indMap.get("maximumValuesToDisplay").equals("-1") && facetEntries.size()>Integer.valueOf(indMap.get("maximumValuesToDisplay"))) {
						Map<String, String> facetMap = new HashMap<>();
						List<String> facetLimits = new ArrayList<>();
						if (!searchCriteria.getControlParameterValues("_wcf.search.facet.field.limit").isEmpty()) {
							facetLimits = searchCriteria.getControlParameterValues("_wcf.search.facet.field.limit");
							for (String item : facetLimits) {
								String[] itemarray = item.split(":");
								if (itemarray[0]!=null && itemarray[1]!=null) {
									facetMap.put(itemarray[0], itemarray[1]);
								}
							}
							if (facetMap.get(key)!=null && facetMap.get(key).equals("-1")) {
								allValuesReturned = "true";
							}else {
								facetEntries = facetEntries.subList(0, Integer.valueOf(indMap.get("maximumValuesToDisplay")));
								allValuesReturned = "false";
							}
						}else {
							facetEntries = facetEntries.subList(0, Integer.valueOf(indMap.get("maximumValuesToDisplay")));
							allValuesReturned = "false";
						}
					}
				}
				facetValue.put(astrFacetEntry, facetEntries);
				indMap.put("allValuesReturned", allValuesReturned);
				facetValue.put("extendedData", indMap);
			}
			if (null!=facetEntries && !facetEntries.isEmpty())
			aFacetValues.add(facetValue);
		}
		
		LOGGER.trace("EXIT");
	}
	//This function is user to remove irrelevant 0 count facet values
		private Map<String, List<String>> createZeroFacetQuery(SearchCriteria searchCriteria) throws Exception {
			if (LOGGER.isTraceEnabled()) {
				LOGGER.trace("ENTRY");
				LOGGER.trace("Search Criteria : " + searchCriteria);
			}
			SearchCriteria zeroSearchCriteria = searchCriteria.clone();
			List<String> facetQueryList = zeroSearchCriteria.getControlParameterValues(SearchExpressionConstants.CTRL_PARAM_SEARCH_FACET);
			if (LOGGER.isTraceEnabled()) {
				LOGGER.trace("facetQueryList: " + facetQueryList);
			}
			//remove previously applied facet filters before querying to get non-empty facets
			List<String> internalFilters = new ArrayList<>();
			if (null!=zeroSearchCriteria.getControlParameterValues(SearchExpressionConstants.CTRL_PARAM_SEARCH_INTERNAL_FILTERQUERY))
				internalFilters = zeroSearchCriteria.getControlParameterValues(SearchExpressionConstants.CTRL_PARAM_SEARCH_INTERNAL_FILTERQUERY);
			if (null!=internalFilters && !internalFilters.isEmpty()) {
				if (LOGGER.isTraceEnabled()) {
					LOGGER.trace("internalFilters: " + internalFilters);
				}
			}
			//remove post filters are postfilters are only used for faceting currently
			zeroSearchCriteria.resetControlParameter(SearchExpressionConstants.CTRL_PARAM_SEARCH_POST_FILTER);
				zeroSearchCriteria.resetControlParameter(SearchExpressionConstants.CTRL_PARAM_SEARCH_INTERNAL_FILTERQUERY);
			
			zeroSearchCriteria.resetControlParameter(SearchExpressionConstants.CTRL_PARAM_SEARCH_FACET);
			
			ResponseEntity zeroSearchResponse = SearchServiceFacade.getInstance().performSearch(zeroSearchCriteria);
			LinkedList<LinkedHashMap> facetList = new LinkedList<>();
			Map<String, List<String>> validEntries = new HashMap<>();
			if (zeroSearchResponse != null && zeroSearchResponse.getBody() != null && zeroSearchResponse.getBody() instanceof Map) {
				Map body = (Map) zeroSearchResponse.getBody();
				//body.remove("HitList");
				if (null!=body.get("facetView") && body.get("facetView") instanceof LinkedList) {
									
					facetList = (LinkedList) body.get("facetView");
					for (LinkedHashMap facet:facetList) {
						String entry = String.valueOf(facet.get("value"));
						List<String> valueList = new ArrayList<>();
						if (null!=facet.get("entry")) {
							List<Map> valueEntries =  (List<Map>) facet.get("entry");
							for (Map valueEntry: valueEntries) {
								if (null!=valueEntry.get("count") && Integer.valueOf(String.valueOf(valueEntry.get("count")))>0)
								if (null!=valueEntry.get("value")) {
									valueList.add(String.valueOf(valueEntry.get("value")));
								}
							}
							if (null!=valueList && !valueList.isEmpty()) {
								if (LOGGER.isTraceEnabled()) {
									LOGGER.trace("entry :"+entry);
									LOGGER.trace("valueList :"+valueList);
								}
								validEntries.put(entry, valueList);
							}
						}
					}
				}
			}
			//if (aggregation != null) {
			if (LOGGER.isTraceEnabled()) {
				LOGGER.trace("EXIT");
			}
			return validEntries;
		}
}
