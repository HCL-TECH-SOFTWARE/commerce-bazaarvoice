package com.hcl.commerce.search.internal.expression.preprocessor;

/**
*=================================================================
Copyright [2021] [HCL America, Inc.]
*=================================================================
**/

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.index.query.QueryStringQueryBuilder;
import org.elasticsearch.search.aggregations.AggregationBuilders;
import org.elasticsearch.search.aggregations.BucketOrder;
import org.elasticsearch.search.aggregations.bucket.range.RangeAggregationBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.hcl.commerce.search.expression.SearchCriteria;
import com.hcl.commerce.search.expression.SearchExpressionConstants;
import com.hcl.commerce.search.internal.config.SearchConfigurationRegistry;
import com.hcl.commerce.search.internal.expression.processor.SearchQueryPreprocessor;
import com.hcl.commerce.search.internal.util.EntitlementHelper;
import com.hcl.commerce.search.rest.util.SearchBodDocumentHelper;

public class SearchFacetQueryPreprocessor extends 
	AbstractSearchQueryPreprocessor implements SearchQueryPreprocessor {

	private static final String CLASSNAME = SearchFacetQueryPreprocessor.class.getName();
	private static final Logger LOGGER = LoggerFactory.getLogger(CLASSNAME);
	
	private static final Map<String, String> SOLR_TO_ES_FIELD = SearchBodDocumentHelper.getSolrToESFieldMap();
	
	private static SearchConfigurationRegistry registry = SearchConfigurationRegistry.getInstance(); 
	
	@Override
	public void invoke(SearchCriteria searchCriteria,
			Object... queryRequestObjects) throws Exception {

		if(LOGGER.isTraceEnabled()) {
			LOGGER.trace("ENTRY");
			LOGGER.trace("SearchCriteria : "+searchCriteria);
			LOGGER.trace("SearchProfile : " + queryRequestObjects[0]);
		}
		
		int counter = 1;
		super.invoke(searchCriteria, queryRequestObjects);
		Map<String, String> queryMap = new HashMap<>();
		String storeId = searchCriteria
				.getControlParameterValue(SearchExpressionConstants.CTRL_PARAM_SEARCH_STORE_ONLINE);
		String catalog = searchCriteria.getFinalControlParameterValue(SearchExpressionConstants.CTRL_PARAM_SEARCH_CATALOG);
		List<String> facetProperties = searchCriteria.getControlParameterValues(SearchExpressionConstants.CTRL_PARAM_SEARCH_FACET_PROPERTIES);
		Map<String, Map> propertyMap = new HashMap<>();
		
		if (facetProperties != null && facetProperties.size() > 0) {
			for (String entry : facetProperties) {
				Map<String, String> facetMap = new HashMap<>();
				
				List<String> keyList = new ArrayList<String>();
				List<String> valueList = new ArrayList<String>();
				
				//Splitting it this way to prevent issues if the facet value contains commas
				String[] splitByEqual = entry.split("=");
				for(int i=0; i<splitByEqual.length; i++) {
					if(i==0) {
						keyList.add(splitByEqual[i]);
					}
					else if(i==splitByEqual.length-1) {
						String val = splitByEqual[i];
						if(val.endsWith(","));
							val = val.substring(0, val.length()-1);
						valueList.add(val);
					}
					else {
						int lastCommaIndex = splitByEqual[i].lastIndexOf(",");
						valueList.add(splitByEqual[i].substring(0, lastCommaIndex));
						keyList.add(splitByEqual[i].substring(lastCommaIndex+1, splitByEqual[i].length()));
					}
				}
				
				for(int i=0; i<keyList.size(); i++) {
					facetMap.put(keyList.get(i), valueList.get(i));
				}

				if (facetMap.get("propertyvalue") != null) {
					if (facetMap.get("propertyvalue").equals("manufacturer.raw")
							|| facetMap.get("propertyvalue").equals("seller.raw")
							|| facetMap.get("propertyvalue").startsWith("prices.")
							|| facetMap.get("propertyvalue").contains("path")) {
						queryMap.put("field" + counter, facetMap.get("propertyvalue").toLowerCase());
						propertyMap.put("field" + counter, facetMap);
					} 
					/* BV START */
					else if (facetMap.get("propertyvalue").contains("BVcustom.X_FIELD3")) {
						queryMap.put("field" + counter, facetMap.get("propertyvalue"));
						propertyMap.put("field" + counter, facetMap);
					} 
					/* BV END */
					else {
						queryMap.put("field" + counter,
								"facets" + "." + facetMap.get("propertyId") + "." + "value.raw");
						propertyMap.put("field" + counter, facetMap);
					}
				}
				counter++;
			}
			// adding manufacturer to facet as it is default
			// queryMap.put("field"+counter, "manufacturer.raw");
			// queryMap.put("field"+(counter+1), "prices.offer_usd");

			int size = 10000;
			Iterator<Entry<String, String>> itr = queryMap.entrySet().iterator();
			List<String> uniqueFacets = new ArrayList<>();
			while (itr.hasNext()) {
				Entry<String, String> entry = itr.next();
				
				if (entry.getKey().startsWith("field") && !entry.getValue().toString().isEmpty()) {
					String facetName = entry.getValue().toString();
					String fieldName = entry.getValue().toString();
					String fieldId = entry.getKey().toString();
					if(fieldName.equals("path")) {
						fieldName = fieldName +"."+catalog;
					}
					if (!uniqueFacets.contains(facetName)){
						uniqueFacets.add(facetName);
					try {
						List<String> postFacets = searchCriteria.getControlParameterValues(SearchExpressionConstants.CTRL_PARAM_SEARCH_POST_FILTER);
						if (!postFacets.isEmpty()) {
							BoolQueryBuilder boolQuery = new BoolQueryBuilder();
							for (String postFacet : postFacets) {
								String[] postArr = postFacet.split(":");
								if (postFacet.length()>0 && !postArr[0].equals(facetName)) {
									QueryStringQueryBuilder postFilterQueryString = QueryBuilders
											.queryStringQuery(postFacet);
									boolQuery.filter(postFilterQueryString);
								}
							}
							if (null!= propertyMap.get(fieldId) && null!=propertyMap.get(fieldId).get("zero_display") && propertyMap.get(fieldId).get("zero_display").equals("true"))
								builder.aggregation(AggregationBuilders.filter(facetName, boolQuery).subAggregation(AggregationBuilders.terms(facetName)
									.field(fieldName).size(size).minDocCount(0)));
							else
								builder.aggregation(AggregationBuilders.filter(facetName, boolQuery).subAggregation(AggregationBuilders.terms(facetName)
										.field(fieldName).size(size)));
						}else {
							if (null!= propertyMap.get(fieldId) && null!=propertyMap.get(fieldId).get("zero_display") && propertyMap.get(fieldId).get("zero_display").equals("true"))
								builder.aggregation(AggregationBuilders.terms(facetName)
								.field(fieldName).size(size).minDocCount(0));
							else
								builder.aggregation(AggregationBuilders.terms(facetName)
										.field(fieldName).size(size));
						}
					}catch (Exception e) {
						System.out.println(entry.getValue().toString() +":"+ e.getMessage());
					}
				}
				}
			}
		} else {
			List<String> facetFields = searchCriteria.getControlParameterValues(SearchExpressionConstants.CTRL_PARAM_SEARCH_FACET_FIELD);
			if (facetFields != null && facetFields.size() > 0) {				
				for (String facet : facetFields) {
					processFacetFieldParameter(facet, storeId, searchCriteria
							.getControlParameterValue(SearchExpressionConstants.CTRL_PARAM_SEARCH_LANGUAGE), catalog);
				}
			}
			
			String facetQueryFields = searchCriteria.getControlParameterValue(SearchExpressionConstants.CTRL_PARAM_SEARCH_FACETQUERY_FIELD);
			if (facetQueryFields != null && facetQueryFields.length() > 0) {
				String[] requestFacetQueries = facetQueryFields.split(SearchExpressionConstants.EXPRESSION_SEPARATOR);
				for (String facet : requestFacetQueries) {
					List<String> facetWithPatternList = applyFieldNamingPattern(facet, searchCriteria);
					for (String facetWithPattern : facetWithPatternList) {
						if (facet.trim().length() > 0) {						
							builder.aggregation(AggregationBuilders.terms(facetWithPattern)
									.field(facetWithPattern).size(10000));
						}
					}
				}
				
			}
		}
		if(LOGGER.isTraceEnabled()) {
			LOGGER.trace("Facet Query : "+builder);
		}
		LOGGER.trace("EXIT");
	}

	/**
	 * This method is use to process the Facet fields.
	 * @param astrFacetFieldValue
	 */
	private void processFacetFieldParameter(String astrFacetFieldValue, String storeId, String languageId, String catalog) {
		LOGGER.trace("ENTRY");
		if (astrFacetFieldValue != null && astrFacetFieldValue.length() > 0) {
			String[] requestFacets = astrFacetFieldValue.split(SearchExpressionConstants.FACET_SEPERATOR);
			for (String facet : requestFacets) {
				if (facet.trim().length() > 0) {
					if (facet.contains(SearchExpressionConstants.EXPRESSION_OPERATOR_ASSIGN)) {
						String facetName = facet.substring(0,
								facet.indexOf(SearchExpressionConstants.EXPRESSION_OPERATOR_ASSIGN));
						String facetValue = facet.substring(
								facet.indexOf(SearchExpressionConstants.EXPRESSION_OPERATOR_ASSIGN) + 1,
								facet.length());

						String[] queryValues = facetValue.split(SearchExpressionConstants.FACET_VALUE_SEPARATOR);
						RangeAggregationBuilder rangeBuilder = AggregationBuilders.range(facetName+"_query");
						String esField = null;
						if (facetName.startsWith("price")) {
							String curr = facetName.substring(facetName.indexOf("_")+1);
							facetName = facetName.replace(curr, "*");
							facetName = SOLR_TO_ES_FIELD.get(facetName);
							esField = facetName.replace("*", curr.toLowerCase());
						}
						if(esField == null) {
							esField = facetName;
						}
						rangeBuilder.field(esField);
						for (String queryValue : queryValues) {
							String[] range = getPriceRange(queryValue);
							if(range[0].equals("*")) {
								rangeBuilder.addUnboundedTo(range[2], Double.valueOf(range[1])+1);
							} else if(range[1].equals("*")) {
								rangeBuilder.addUnboundedFrom(range[2], Double.valueOf(range[0])+1);
							} else {
								rangeBuilder.addRange(range[2], Double.valueOf(range[0])+1, Double.valueOf(range[1])+1);
							}
							if (LOGGER.isTraceEnabled()) {
								LOGGER.trace("Facet query: " + facetName + ":(" + queryValue + ")");
							}
						}
						builder.aggregation(rangeBuilder);
					} else {
						String esField = "";
						if (facet.startsWith("price")) {
							String curr = facet.substring(facet.indexOf("_")+1);
							String facetName = facet;
							facetName = facetName.replace(curr, "*");
							facetName = SOLR_TO_ES_FIELD.get(facetName);
							esField = facetName.replace("*", curr.toLowerCase());
						} else if(facet.equals("parentCatgroup_id_search")) {
							esField = "path."+catalog;
						} else {
							esField = SOLR_TO_ES_FIELD.get(facet);
							if(facet != null && facet.startsWith("ads")) {
								esField = registry.getFacetAttributeKey(facet, storeId, languageId);
							} else if(esField != null && esField.contains("normalized")) {
								esField = esField.replace("normalized", "raw");
							}
							if(esField == null) {
								esField = facet;
							}
						}
						builder.aggregation(AggregationBuilders.terms(facet)
								.field(esField).order(BucketOrder.key(true)).size(100));
					}
				}
			}
		}
		LOGGER.trace("EXIT");
	}
	/**
	 * This method is use to get the range.
	 * @param value
	 * @return returnRangeValue
	 */
	private String[] getPriceRange(String value) {
		if (LOGGER.isTraceEnabled()) {
			LOGGER.trace("ENTRY");
			LOGGER.trace(value);
		}
		String[] returnRangeValue = new String[3];
		String obj = "";
		if(value != null) {
			obj = value.replace("{", "").trim();
			obj = obj.replace("]", "").trim();
			obj = obj.replace("[", "").trim();
			obj = obj.replace("}", "").trim();
			String[] range = obj.split("TO");
			if(range != null && range.length == 2) {
				returnRangeValue[0] = range[0].trim();
				returnRangeValue[1] = range[1].trim();
				returnRangeValue[2] = value;
			}
		}
		LOGGER.trace("EXIT");
		return returnRangeValue;
	}
	
	/**
	 * This method will apply field name with specified field naming pattern for
	 * example, if the naming pattern is price_currency_contractId, then for
	 * price_USD field, it will change to the list of price_USD_contractId. If
	 * the field name do not start with "price", or it is using the old
	 * compatible mode, no change to the input field name
	 * 
	 * @param origFieldName
	 * @return fieldNameWithPattern
	 */
	protected List<String> applyFieldNamingPattern(String origFieldName, SearchCriteria searchCriteria)
			throws Exception {
		return EntitlementHelper.applyFieldNamingPattern(origFieldName,
				searchCriteria);
	}
}
