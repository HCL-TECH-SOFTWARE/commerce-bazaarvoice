package com.hcl.commerce.search.internal.expression.provider;

/**
	*==================================================
	Copyright [2021] [HCL Technologies]

	Licensed under the Apache License, Version 2.0 (the "License");
	you may not use this file except in compliance with the License.
	You may obtain a copy of the License at

		http://www.apache.org/licenses/LICENSE-2.0


	Unless required by applicable law or agreed to in writing, software
	distributed under the License is distributed on an "AS IS" BASIS,
	WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
	See the License for the specific language governing permissions and
	limitations under the License.
	*==================================================
**/

import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.LoggerFactory;
import org.slf4j.Logger;

import com.hcl.commerce.search.exception.SearchApplicationException;
import com.hcl.commerce.search.expression.SearchCriteria;
import com.hcl.commerce.search.expression.SearchExpressionConstants;
import com.hcl.commerce.search.expression.provider.SearchExpressionProvider;
import com.hcl.commerce.search.internal.config.ValueMappingService;
import com.hcl.commerce.search.internal.util.FacetHelper;
//import com.ibm.commerce.foundation.common.util.logging.LoggingHelper;
//import com.ibm.commerce.search.config.SearchConfigurationConstants;
import com.hcl.commerce.search.internal.util.StoreHelper;

/**
 * This is the implementation of the search expression provider for handling the
 * search by facet request. It adds additional facets when provided through
 * _wcf.search.facet and skips those facets defined in this exclude list,
 * _wcf.search.exclude.facet. The resulting expression will be added back into
 * the searchCriteria object (_wcf.search.internal.meta) and to be encoded into
 * the meta string (_wcf.search.meta) later on. Note that the facet conditions
 * should be passed in with a separator using
 * <code>SearchExpressionConstants.FACET_SEPERATOR</code>.
 */
public class SearchByCustomBVFacetExpressionProvider extends
		AbstractSearchExpressionProvider implements SearchExpressionProvider {

	private static ValueMappingService iMappingService = ValueMappingService.getInstance();

	private static final String CLASSNAME = SearchByCustomBVFacetExpressionProvider.class.getName();

	private static final Logger LOGGER = LoggerFactory.getLogger(SearchByCustomBVFacetExpressionProvider.class);

	private static final String PROPERTY_NAME_CATEGORY_FACET_LIMIT_FOR_KEYWORD_SEARCH = "categoryFacetLimitForKeywordSearch";

	/**
	 * This parameter can be used to prevent facets from being returned. If set
	 * to 'true', no facets will be returned except for the ones passed in on
	 * the _wcf.search.facet parameter.
	 */
	private static final String CTRL_PARAM_SKIP_FACETS = "_wcf.search.skipfacets";
	private static final int MAX_NUM_OF_SELECTED_FACETS = 20;
	private static final String STR_DOT = ".";

	/**
	 * @throws Exception
	 * @see com.hcl.commerce.search.internal.expression.provider.AbstractSearchExpressionProvider#invoke(com.hcl.commerce.search.expression.SearchCriteria)
	 */
	public void invoke(SearchCriteria searchCriteria)
			throws Exception {
		if (LOGGER.isTraceEnabled()) {
			LOGGER.trace("ENTRY");
			LOGGER.trace("SearchCriteria : " + searchCriteria);

		}

		super.invoke(searchCriteria);

		String strTerm = searchCriteria.getControlParameterValue(SearchExpressionConstants.CTRL_PARAM_SEARCH_TERM);
		Map<String, Map<String, String>> facetProperties = fetchFacetProperties(searchCriteria);
		List <String>facetPropList = new ArrayList<>();
		
		if (facetProperties.size() > 0) {
			
			int i = 0;
			
			Iterator<Entry<String, Map<String, String>>> iterator = facetProperties.entrySet().iterator();
			while (iterator.hasNext()) {
				StringBuffer fentry = new StringBuffer();
				Entry<String, Map<String, String>> entry=iterator.next();
				Map<String, String> properties = entry.getValue();
				properties.forEach((k,v) -> fentry.append(k+"="+v+",")
				);
				facetPropList.add(fentry.toString());
			}
			
			/* BV START */
			facetPropList.add("propertyvalue=BVcustom.X_FIELD3,propertyId=BVcustom.X_FIELD3,name=Rating,allowMultipleValueSelection=true,maximumValuesToDisplay=5,max_display=5,displaySequence=1.0,zero_display=false,fname=Rating,fdesc=Rating,sortorder=1,displayable=true,");
			/* BV END */
			
			if (facetPropList != null && facetPropList.size()>0) {
				searchCriteria.setControlParameterValue(
						SearchExpressionConstants.CTRL_PARAM_SEARCH_FACET_PROPERTIES,
						facetPropList);
			}
		}
		
		HashSet<String> hsSelectedFacets = processFacetSelections(searchCriteria, facetProperties);
		if (skipFacets(searchCriteria)) {
			facetProperties = lookupFacetProperties(facetProperties,
					hsSelectedFacets);
		}

		LOGGER.trace("EXIT");
	}

	/**
	 * This method read facet properties from DB
	 * 
	 * @param searchCriteria
	 * @return A map containing the facet properties for a search index column. The
	 *         key in the map is the search index column name, the value is a list
	 *         of facetable properties fetched from the database.
	 */
	protected Map<String, Map<String, String>> fetchFacetProperties(SearchCriteria searchCriteria) {
		LOGGER.trace("ENTRY");

		String contractID = searchCriteria.getFinalControlParameterValue(SearchExpressionConstants.CTRL_PARAM_SEARCH_CURRENT_CONTRACT);
		
		Map<String, Map<String, String>> facetProperties = new HashMap<String, Map<String, String>>();
		// Retrieve all applicable facets for category based search or browsing
		String strCategory = searchCriteria
				.getControlParameterValue(SearchExpressionConstants.CTRL_PARAM_SEARCH_CATEGORY);
		String strSearchProfile = searchCriteria
				.getControlParameterValue(SearchExpressionConstants.CTRL_PARAM_SEARCH_PROFILE);
		String strTerm = searchCriteria.getControlParameterValue(SearchExpressionConstants.CTRL_PARAM_SEARCH_TERM);
		// TODO getFinalControlParameterValue start
		String strCurrencyCode = searchCriteria
				.getControlParameterValue(SearchExpressionConstants.CTRL_PARAM_SEARCH_CURRENCY);
		String strCatalogId = searchCriteria
				.getControlParameterValue(SearchExpressionConstants.CTRL_PARAM_SEARCH_CATALOG);
		String languageId = searchCriteria
				.getControlParameterValue(SearchExpressionConstants.CTRL_PARAM_SEARCH_LANGUAGE);
		String storeId = searchCriteria
				.getControlParameterValue(SearchExpressionConstants.CTRL_PARAM_SEARCH_STORE_ONLINE);
		
		Boolean isDeepSearchEnabled = false;
		try {
			isDeepSearchEnabled = StoreHelper.isDeepSearchEnabled(storeId, languageId);
		} catch (Exception e1) {
			throw new SearchApplicationException(e1);
		}
		
		// TODO getFinalControlParameterValue end
		boolean bUseCategoryFacetDisplaySettingsForSearch = FacetHelper
				.useCategoryFacetDisplaySettingsForSearch();
		FacetHelper facetHelper = new FacetHelper();
		try {
			if (!isDeepSearchEnabled && strCategory != null && strCategory.length() > 0
					&& (null == strTerm || strTerm.equals(""))) {
				// $ANALYSIS-IGNORE
				facetProperties.putAll(facetHelper
						.getFacetConfigurationForCategory(strCategory, languageId,
								SearchExpressionConstants.INDEX_NAME_CATALOG_ENTRY,
								 Integer.valueOf(storeId),
								strCurrencyCode, strCatalogId, contractID, searchCriteria));
			} else if(!isDeepSearchEnabled && bUseCategoryFacetDisplaySettingsForSearch){
				//It is keyword search, If it is being specified to use categoryFacetDisplaySettingForSearch then 
				// retrieve all applicable facets for category
				// $ANALYSIS-IGNORE
				facetProperties.putAll(facetHelper
						.getFacetConfigurationForCategory(strCategory, languageId,
						SearchExpressionConstants.INDEX_NAME_CATALOG_ENTRY,
						Integer.valueOf(storeId),
						strCurrencyCode, strCatalogId,contractID, searchCriteria));
			}else{
				// we are not browsing... are we searching then?
				// Retrieve all applicable facets for keyword search
				// $ANALYSIS-IGNORE
				  facetProperties.putAll(facetHelper.getFacetConfigurationForKeywordSearch(
				  Integer.valueOf(storeId),  strCurrencyCode, contractID, searchCriteria, languageId, new ArrayList<String>()));

			}
		} catch (Exception e) {
			throw new SearchApplicationException(e);
		}

		// remove facets to be excluded
		// TODO: exclude facets
		/*
		 * SearchConfigurationRegistry searchRegistry = SearchConfigurationRegistry
		 * .getInstance(); String[] excludeFacetNames = searchRegistry.getExcludeFacets(
		 * strSearchProfile, strCategory); if (excludeFacetNames != null &&
		 * excludeFacetNames.length > 0) { Object[] facetPropertyNames =
		 * facetProperties.keySet().toArray(); for (int i = 0; i <
		 * facetPropertyNames.length; i++) { String facetPropertyName = (String)
		 * facetPropertyNames[i]; for (int j = 0; j < excludeFacetNames.length; j++) {
		 * if (facetPropertyName.startsWith(excludeFacetNames[j])) {
		 * facetProperties.remove(facetPropertyName); break; } } } }
		 */
		LOGGER.trace("EXIT");

		return facetProperties;
	}

	/**
	 * This method processes facet selections specified by the _wcf.seach.facet
	 * control parameter. These selections will be added to the final query as an fq
	 * parameter. This method also processes facets excluded by the
	 * _wcf.search.exclude.facet parameter.
	 * 
	 * @param searchCriteria
	 * @param facetProperties 
	 * 
	 * @return a list of facetable attribute field names selected by the client
	 *         (specified by the _wcf.search.facet control parameter).
	 */
	private HashSet<String> processFacetSelections(SearchCriteria searchCriteria, Map<String, Map<String, String>> facetProperties) {
		LOGGER.trace("ENTRY");

		HashSet<String> hsFacetableAttributeNames = new HashSet<String>(
				MAX_NUM_OF_SELECTED_FACETS);

		// Check for query adjustment - _wcf.search.facet
		List<String> encodedFacets = searchCriteria
				.getControlParameterValues(SearchExpressionConstants.CTRL_PARAM_SEARCH_FACET);
		String catalogId = searchCriteria
				.getFinalControlParameterValue(SearchExpressionConstants.CTRL_PARAM_SEARCH_CATALOG);
		if (LOGGER.isTraceEnabled() && encodedFacets!= null) {
			LOGGER.trace(" encodedFacets.size() " + encodedFacets.size());
		}
		if (encodedFacets != null && encodedFacets.size() > 0) {
			for (String encodedFacet : encodedFacets) {
				String decodedFacet = "";

					if (LOGGER.isTraceEnabled()) {
						LOGGER.trace("Search facet (encoded): " + encodedFacet);
					}
				try {
					decodedFacet = URLDecoder.decode(encodedFacet,
						SearchExpressionConstants.ENCODING_UTF_8);
				} catch (UnsupportedEncodingException e) {
					decodedFacet = encodedFacet;

				} catch (IllegalArgumentException e) {
					decodedFacet = encodedFacet;
				}
				if(decodedFacet.startsWith("path.tree")) {
					decodedFacet = decodedFacet.replace(STR_DOT, STR_DOT+catalogId+STR_DOT);
				}
					String strFieldName = decodedFacet.split(":")[0];
					hsFacetableAttributeNames.add(strFieldName);
				if (LOGGER.isTraceEnabled()) {
					LOGGER.trace("Search facet (decoded): " + decodedFacet);
				}
				String contractID = searchCriteria.getFinalControlParameterValue(SearchExpressionConstants.CTRL_PARAM_SEARCH_CURRENT_CONTRACT);
				if (decodedFacet != null && decodedFacet.length() > 0) {
					if (decodedFacet.contains("price_")) {
						String[] priceFields = decodedFacet.split(":");
						String[] splitCurr = priceFields[0].split("_");
						if (StringUtils.isEmpty(contractID)) {
							contractID = "offer";
						}
						decodedFacet = "prices."+contractID+"."+splitCurr[1]+":"+priceFields[1];
					}
					if (facetProperties != null) {
						
						String []facetname = decodedFacet.split(":");
						if (facetname[0].equals("manufacturer.raw") && facetProperties.get("manufacturer.raw")!=null
								&& facetProperties.get("manufacturer.raw").get("allowMultipleValueSelection")!=null 
								&& facetProperties.get("manufacturer.raw").get("allowMultipleValueSelection").equals("true")) {
							if(searchCriteria.getControlParameterValue(SearchExpressionConstants.CTRL_PARAM_SEARCH_POST_FILTER)!=null) {
								
								List<String> postFacets = searchCriteria.getControlParameterValues(SearchExpressionConstants.CTRL_PARAM_SEARCH_POST_FILTER);
								int mf = 0;
								for (int i =0; i<postFacets.size();i++) {
									if(postFacets.get(i).contains(facetname[0])) {
										postFacets.set(i, postFacets.get(i)+" OR "+ decodedFacet);
										mf = 1;
									} 
								}
								if (mf == 0) {
									postFacets.add(decodedFacet);
								}
								searchCriteria.setControlParameterValue(SearchExpressionConstants.CTRL_PARAM_SEARCH_POST_FILTER, postFacets);
								
							}else {
							searchCriteria.addControlParameterValue(
									SearchExpressionConstants.CTRL_PARAM_SEARCH_POST_FILTER,
									decodedFacet);
							}
							
						}else if (facetname[0].startsWith("path") && facetProperties.get("path")!=null
								&& facetProperties.get("path").get("allowMultipleValueSelection")!=null 
								&& facetProperties.get("path").get("allowMultipleValueSelection").equals("true")) {
							if(searchCriteria.getControlParameterValue(SearchExpressionConstants.CTRL_PARAM_SEARCH_POST_FILTER)!=null) {
								
								List<String> postFacets = searchCriteria.getControlParameterValues(SearchExpressionConstants.CTRL_PARAM_SEARCH_POST_FILTER);
								int path = 0;
								for (int i =0; i<postFacets.size();i++) {
									if(postFacets.get(i).contains(facetname[0]) || postFacets.get(i).startsWith("path")) {
										postFacets.set(i, postFacets.get(i)+" OR "+ decodedFacet);
										path = 1;
									} 
								}
								if (path == 0) {
									postFacets.add(decodedFacet);
								}
								searchCriteria.setControlParameterValue(SearchExpressionConstants.CTRL_PARAM_SEARCH_POST_FILTER, postFacets);
							}else {
							searchCriteria.addControlParameterValue(
									SearchExpressionConstants.CTRL_PARAM_SEARCH_POST_FILTER,
									decodedFacet);
							}
							/*searchCriteria.addControlParameterValue(
									SearchExpressionConstants.CTRL_PARAM_SEARCH_POST_FILTER,
									decodedFacet);*/
						}else {
							String []attrName = facetname[0].split("\\.");
							if (attrName.length>= 2 && attrName[1]!=null && facetProperties.get(attrName[1])!=null
									&& facetProperties.get(attrName[1]).get("allowMultipleValueSelection")!=null 
									&& facetProperties.get(attrName[1]).get("allowMultipleValueSelection").equals("true")) {
								/*searchCriteria.addControlParameterValue(
										SearchExpressionConstants.CTRL_PARAM_SEARCH_POST_FILTER,
										decodedFacet);*/
								if(searchCriteria.getControlParameterValue(SearchExpressionConstants.CTRL_PARAM_SEARCH_POST_FILTER)!=null) {
									
									List<String> postFacets = searchCriteria.getControlParameterValues(SearchExpressionConstants.CTRL_PARAM_SEARCH_POST_FILTER);
									int attr = 0;
									for (int i =0; i<postFacets.size();i++) {
										if(postFacets.get(i).contains(facetname[0])) {
											postFacets.set(i, postFacets.get(i)+" OR "+ decodedFacet);
											attr = 1;
										} 
									}
									if (attr == 0) {
										postFacets.add(decodedFacet);
									}
									searchCriteria.setControlParameterValue(SearchExpressionConstants.CTRL_PARAM_SEARCH_POST_FILTER, postFacets);
									
								}else {
								searchCriteria.addControlParameterValue(
										SearchExpressionConstants.CTRL_PARAM_SEARCH_POST_FILTER,
										decodedFacet);
								}
							}else {
								searchCriteria.addControlParameterValue(
										SearchExpressionConstants.CTRL_PARAM_SEARCH_INTERNAL_FILTERQUERY,
										decodedFacet);
							}
							
						}
					}else {
					searchCriteria.addControlParameterValue(
							SearchExpressionConstants.CTRL_PARAM_SEARCH_INTERNAL_FILTERQUERY,
							decodedFacet);
					}
					searchCriteria.addControlParameterValue(
							SearchExpressionConstants.CTRL_PARAM_SEARCH_INTERNAL_META,
							decodedFacet);
				}
			}
		}

		// Check for query adjustment - _wcf.search.exclude.facet
		String excludeFacet = searchCriteria
				.getControlParameterValue(SearchExpressionConstants.CTRL_PARAM_SEARCH_EXCLUDE_FACET);
		String decodedExcludeFacet = "";
		if (excludeFacet != null && excludeFacet.length() > 0) {
			try {
				decodedExcludeFacet = URLDecoder.decode(excludeFacet,
						SearchExpressionConstants.ENCODING_UTF_8);
			} catch (UnsupportedEncodingException e) {
				decodedExcludeFacet = excludeFacet;

			} catch (IllegalArgumentException e) {
				decodedExcludeFacet = excludeFacet;
			}
			if (LOGGER.isTraceEnabled()) {
				LOGGER.trace(
						"Exclude facet (encoded): " + excludeFacet + "Exclude facet (decoded): " + decodedExcludeFacet);
			}

			String[] facets = decodedExcludeFacet
					.split(SearchExpressionConstants.FACET_SEPERATOR);
			for (String facet : facets) {
				searchCriteria.removeControlParameterValue(
						SearchExpressionConstants.CTRL_PARAM_SEARCH_INTERNAL_META,
						facet);
			}
		}
		LOGGER.trace("EXIT");
		return hsFacetableAttributeNames;
	}

	/**
	 * Looks up facet properties for a given set of facets.
	 * 
	 * @param amapFacetProperties
	 *            - map of facet properties
	 * @param ahsFacetName
	 *            - names of facets to look up properties for.
	 * @return facet properties for give facets
	 */
	private Map<String, Map<String, String>> lookupFacetProperties(
			Map<String, Map<String, String>> amapFacetProperties,
			HashSet<String> ahsFacetNames) {
		LOGGER.trace("ENTRY");

		Map<String, Map<String, String>> mapPropertiesOfSelectedFacets = new HashMap<String, Map<String, String>>(
				amapFacetProperties.size());

		Iterator<Entry<String, Map<String, String>>> iterator = amapFacetProperties.entrySet().iterator();
		while (iterator.hasNext()) {
			Entry<String, Map<String, String>> entry=iterator.next();
			String facetName = entry.getKey();
			if (ahsFacetNames.contains(facetName)) {
				Map<String, String> mapProperties = entry.getValue();
				mapPropertiesOfSelectedFacets.put(facetName, mapProperties);
			}
		}

		LOGGER.trace("EXIT");
		return mapPropertiesOfSelectedFacets;
	}

	private boolean skipFacets(SearchCriteria searchCriteria) {
		LOGGER.trace("ENTRY");

		boolean bSkipFacets = false;
		String strSkipFacets = searchCriteria.getControlParameterValue(CTRL_PARAM_SKIP_FACETS);
		if (strSkipFacets != null && strSkipFacets.trim().equals("true")) {
			bSkipFacets = true;
		}

		LOGGER.trace("EXIT");
		return bSkipFacets;
	}

	/**
	 * Inner facet class used for sorting and comparison
	 */
	private class Facet implements Comparable<Facet> {


		private Map<String, String> iProperties = null;

		/**
		 * Constructor
		 * 
		 * @param facetProperties
		 */
		public Facet(Map<String, String> facetProperties) {
			super();
			iProperties = facetProperties;
		}

		/**
		 * Retrieves the internal facet properties.
		 * 
		 * @return Map of facet properties
		 */
		public Map<String, String> getProperties() {
			return iProperties;
		}

		/**
		 * @see java.lang.Comparable#compareTo(java.lang.Object)
		 */
		@Override
		public int compareTo(Facet anotherFacet) {
			String facetSequence = getProperties().get(
					FacetHelper.FACET_PROPERTY_ATTRIBUTE_SEQUENCE);
			String anotherFacetSequence = anotherFacet.getProperties().get(
					FacetHelper.FACET_PROPERTY_ATTRIBUTE_SEQUENCE);
			if (facetSequence == anotherFacetSequence) {
				return 0;
			} 
			if (null == facetSequence) {
				return -1;
			} else if (null == anotherFacetSequence) {
				return 1;
			}
				
			BigDecimal bdFacetSequence        = new BigDecimal(facetSequence);
			BigDecimal bdAnotherFacetSequence = new BigDecimal(anotherFacetSequence);
				
			return bdFacetSequence.compareTo(bdAnotherFacetSequence);
		}

		@Override
		public boolean equals(Object o) {
			// TODO Auto-generated method stub
			return super.equals(o);
		}

		@Override
		public int hashCode() {
			// TODO Auto-generated method stub
			return super.hashCode();
		}
	}
}